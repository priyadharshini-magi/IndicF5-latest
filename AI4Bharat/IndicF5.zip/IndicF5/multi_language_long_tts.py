import asyncio
import edge_tts

voices = {
    "tamil.wav": (
    "S C M SILK Supplier Portal க்கு வரவேற்கிறோம். "
    "S C M SILK Supplier Portal க்கு Appointment எவ்வாறு பதிவு செய்வது என்பதை படிப்படியாக பார்க்கலாம். "
    "Google Chrome ஐ திறக்கவும். "
    "Search Box-ல் www.Thee S C M silk dot com என்று type செய்து Enter அழுத்தவும். "
    "Home Page open ஆகும். "
    "Login Supplier Portal click செய்யவும். "
    "உங்கள் User name மற்றும் Password ஐ enter செய்யவும், Login click செய்யவும். "
    "உள்நுழைந்த பிறகு, அனைத்து Option இடது பக்கத்தில் காணப்படும். "
    "Appointment option click செய்யவும். "
    "Appointment Screen open ஆகும். "
    "Supplier Name தானாகவே (Auto Display) காண்பிக்கப்படும். "
    "Visitor Name பகுதியில், எங்கள் அலுவலகத்திற்கு வருகை தரும் நபரின் பெயரை குறிப்பிடவும். "
    "Designation பகுதியில், சந்திக்க விரும்பும் நபரைத் தேர்வு செய்யவும். "
    "MD Sir, GM Sir, Manager, Employee, அல்லது Others. "
    "வருகையாளரின் Mobile Number enter செய்யவும். "
    "Number of Persons Visit பகுதியில் மொத்த வருகையாளர்களின் எண்ணிக்கையை குறிப்பிடவும். "
    "Visit Date பகுதியில், வருகை தரும் தேதியைத் தேர்வு செய்யவும். "
    "Visit Time தேர்வு செய்யவும் Morning அல்லது Afternoon. "
    "Comment Section இல் வருகையின் நோக்கத்தை குறிப்பிடவும். "
    "அனைத்து விவரங்களையும் நிரப்பிய பிறகு, Submit என்ற option click செய்யவும். "
    "Success Alert காண்பிக்கப்படும். "
    "OK என்பதை click செய்யவும். "
    "எங்கள் Management Team உங்களை தொடர்பு கொள்வார்கள். "
    "நன்றி. நல்ல நாளாக அமைய வாழ்த்துக்கள்.",
        "ta-IN-PallaviNeural"
    ),

    "malayalam.wav": (
    "S C M SILK സപ്ലയർ പോർട്ടലിലേക്കു സ്വാഗതം. "
    "ഈ വീഡിയോയിൽ S C M SILK സപ്ലയർ പോർട്ടലിൽ അപോയിന്റ്മെന്റ് എങ്ങനെ ബുക്ക് ചെയ്യാമെന്ന് സ്റ്റെപ്പ് ബൈ സ്റ്റെപ്പായി വിശദീകരിക്കുന്നു. "
    "ആദ്യം Google Chrome തുറക്കുക. "
    "അഡ്രസ് ബാറിൽ www. the S C M silk dot com ടൈപ്പ് ചെയ്ത് Enter അമർത്തുക. "
    "ഹോം പേജ് തുറക്കും. "
    "Login Supplier Portal ക്ലിക്ക് ചെയ്യുക. "
    "നിങ്ങളുടെ User name and  Password നൽകുക, തുടർന്ന് Login ക്ലിക്ക് ചെയ്യുക. "
    "ലോഗിൻ ചെയ്ത ശേഷം, എല്ലാ ഓപ്ഷനുകളും ഇടത് വശത്ത് കാണാം. "
    "Appointment ഓപ്ഷനിൽ ക്ലിക്ക് ചെയ്യുക. "
    "Appointment Screen തുറക്കും. "
    "Supplier Name സ്വയമേവ പ്രദർശിപ്പിക്കും. "
    "Visitor Name ഫീൽഡിൽ ഓഫീസിൽ സന്ദർശിക്കുന്ന വ്യക്തിയുടെ പേര് നൽകുക. "
    "Designation ഫീൽഡിൽ സന്ദർശകൻ ആരെയാണു കാണാൻ ആഗ്രഹിക്കുന്നത് എന്ന് തിരഞ്ഞെടുക്കുക. "
    "ഉദാഹരണത്തിന് MD Sir, GM Sir, Manager, Employee, അല്ലെങ്കിൽ Others. "
    "സന്ദർശകന്റെ Mobile Number നൽകുക. "
    "Number of Persons Visit എന്നതിൽ മൊത്തം സന്ദർശകരുടെ എണ്ണം നൽകുക. "
    "Visit Date തിരഞ്ഞെടുക്കുക. "
    "Visit Time തിരഞ്ഞെടുക്കുക, Morning അല്ലെങ്കിൽ Afternoon. "
    "Comment Section ൽ സന്ദർശനത്തിന്റെ ഉദ്ദേശ്യം നൽകുക. "
    "എല്ലാ വിവരങ്ങളും നൽകിയ ശേഷം, Submit ക്ലിക്ക് ചെയ്യുക. "
    "ഒരു Success Alert പ്രദർശിപ്പിക്കും. "
    "OK ക്ലിക്ക് ചെയ്യുക. "
    "ഞങ്ങളുടെ Management Team നിങ്ങളെ ബന്ധപ്പെടും. "
    "നന്ദി. നല്ലൊരു ദിവസം ആശംസിക്കുന്നു.",
        "ml-IN-SobhanaNeural"
    
    ),

    "telugu.wav": (
    "S C M SILK సరఫరాదారు పోర్టల్‌కు స్వాగతం. "
    "ఈ వీడియోలో SCM SILK సరఫరాదారు పోర్టల్‌లో అపాయింట్‌మెంట్ ఎలా బుక్ చేయాలో స్టెప్ బై స్టెప్‌గా వివరించబడుతుంది. "
    "మొదట Google Chrome ఓపెన్ చేయండి. "
    "అడ్రస్ బార్‌లో www dot the scm silk dot com టైప్ చేసి Enter నొక్కండి. "
    "హోమ్ పేజ్ ఓపెన్ అవుతుంది. "
    "Login Supplier Portal పై క్లిక్ చేయండి. "
    "మీ User ID మరియు Password నమోదు చేసి, Login పై క్లిక్ చేయండి. "
    "లాగిన్ అయిన తర్వాత, అన్ని ఆప్షన్లు ఎడమ వైపు కనిపిస్తాయి. "
    "Appointment ఆప్షన్‌పై క్లిక్ చేయండి. "
    "Appointment Screen ఓపెన్ అవుతుంది. "
    "Supplier Name ఆటోమేటిక్‌గా చూపబడుతుంది. "
    "Visitor Name ఫీల్డ్‌లో కార్యాలయాన్ని సందర్శించే వ్యక్తి పేరు నమోదు చేయండి. "
    "Designation ఫీల్డ్‌లో సందర్శకుడు ఎవరిని కలవాలనుకుంటున్నారో ఎంపిక చేయండి. "
    "ఉదాహరణకు MD Sir, GM Sir, Manager, Employee, లేదా Others. "
    "సందర్శకుడి Mobile Number నమోదు చేయండి. "
    "Number of Persons Visit లో మొత్తం సందర్శకుల సంఖ్య నమోదు చేయండి. "
    "Visit Date ను ఎంపిక చేయండి. "
    "Visit Time ను ఎంపిక చేయండి, ఉదయం లేదా మధ్యాహ్నం. "
    "Comment Section లో సందర్శన ఉద్దేశాన్ని నమోదు చేయండి. "
    "అన్ని వివరాలు నమోదు చేసిన తర్వాత, Submit పై క్లిక్ చేయండి. "
    "ఒక Success Alert చూపబడుతుంది. "
    "OK పై క్లిక్ చేయండి. "
    "మా Management Team మీను సంప్రదిస్తుంది. "
    "ధన్యవాదాలు. మంచి రోజు గడపండి."
,
    "te-IN-ShrutiNeural"
),

    "kannada.wav": (
    "S C M SILK ಪೂರೈಕೆದಾರ ಪೋರ್ಟಲ್‌ಗೆ ಸ್ವಾಗತ. "
    "ಈ ವಿಡಿಯೋದಲ್ಲಿ S C M SILK ಪೂರೈಕೆದಾರ ಪೋರ್ಟಲ್‌ನಲ್ಲಿ ಅಪಾಯಿಂಟ್‌ಮೆಂಟ್ ಅನ್ನು ಹೇಗೆ ಬುಕ್ ಮಾಡುವುದು ಎಂಬುದನ್ನು ಹಂತ ಹಂತವಾಗಿ ವಿವರಿಸಲಾಗುತ್ತದೆ. "
    "ಮೊದಲು Google Chrome ಅನ್ನು ತೆರೆಯಿರಿ. "
    "ಅಡ್ರೆಸ್ ಬಾರ್‌ನಲ್ಲಿ www dot the scm silk dot com ಅನ್ನು ಟೈಪ್ ಮಾಡಿ Enter ಒತ್ತಿರಿ. "
    "ಹೋಮ್ ಪೇಜ್ ತೆರೆಯುತ್ತದೆ. "
    "Login Supplier Portal ಮೇಲೆ ಕ್ಲಿಕ್ ಮಾಡಿ. "
    "ನಿಮ್ಮ User name ಮತ್ತು Password ಅನ್ನು ನಮೂದಿಸಿ, ನಂತರ Login ಮೇಲೆ ಕ್ಲಿಕ್ ಮಾಡಿ. "
    "ಲಾಗಿನ್ ಆದ ನಂತರ, ಎಲ್ಲಾ ಆಯ್ಕೆಗಳು ಎಡಭಾಗದಲ್ಲಿ ಕಾಣಿಸುತ್ತವೆ. "
    "Appointment ಆಯ್ಕೆಯ ಮೇಲೆ ಕ್ಲಿಕ್ ಮಾಡಿ. "
    "Appointment Screen ತೆರೆಯುತ್ತದೆ. "
    "Supplier Name ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಪ್ರದರ್ಶಿಸಲಾಗುತ್ತದೆ. "
    "Visitor Name ಫೀಲ್ಡ್‌ನಲ್ಲಿ ಕಚೇರಿಗೆ ಭೇಟಿ ನೀಡುವ ವ್ಯಕ್ತಿಯ ಹೆಸರನ್ನು ನಮೂದಿಸಿ. "
    "Designation ಫೀಲ್ಡ್‌ನಲ್ಲಿ ಭೇಟಿದಾರರು ಯಾರನ್ನು ಭೇಟಿಯಾಗಲು ಬಯಸುತ್ತಾರೆ ಎಂಬುದನ್ನು ಆಯ್ಕೆಮಾಡಿ. "
    "ಉದಾಹರಣೆಗೆ MD Sir, GM Sir, Manager, Employee ಅಥವಾ Others. "
    "ಭೇಟಿದಾರರ Mobile Number ಅನ್ನು ನಮೂದಿಸಿ. "
    "Number of Persons Visit ನಲ್ಲಿ ಒಟ್ಟು ಭೇಟಿದಾರರ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ. "
    "Visit Date ಅನ್ನು ಆಯ್ಕೆಮಾಡಿ. "
    "Visit Time ಅನ್ನು ಆಯ್ಕೆಮಾಡಿ, Morning ಅಥವಾ Afternoon. "
    "Comment Section ನಲ್ಲಿ ಭೇಟಿ."
    "ಎಲ್ಲಾ ವಿವರಗಳನ್ನು ತುಂಬಿದ ನಂತರ, Submit ಮೇಲೆ ಕ್ಲಿಕ್ ಮಾಡಿ. "
    "ಒಂದು Success Alert ಪ್ರದರ್ಶಿಸಲಾಗುವುದು. "
    "OK ಮೇಲೆ ಕ್ಲಿಕ್ ಮಾಡಿ. "
    "ನಮ್ಮ Management Team ನಿಮ್ಮನ್ನು ಸಂಪರ್ಕಿಸುತ್ತಾರೆ. "
    "ಧನ್ಯವಾದಗಳು. ಉತ್ತಮ ದಿನವನ್ನು ಕಳೆಯಿರಿ.",
    "kn-IN-SapnaNeural"
    ),

    "hindi.wav": (
    "S C M SILK सप्लायर पोर्टल में आपका स्वागत है। "
    "इस वीडियो में SCM SILK सप्लायर पोर्टल में अपॉइंटमेंट कैसे बुक करें, यह स्टेप बाय स्टेप बताया गया है। "
    "सबसे पहले Google Chrome खोलें। "
    "एड्रेस बार में www dot the scm silk dot com टाइप करें और Enter दबाएँ। "
    "होम पेज खुल जाएगा। "
    "Login Supplier Portal पर क्लिक करें। "
    "अपना User name और Password दर्ज करें, फिर Login पर क्लिक करें। "
    "लॉगिन करने के बाद, सभी विकल्प बाईं ओर दिखाई देंगे। "
    "Appointment विकल्प पर क्लिक करें। "
    "Appointment Screen खुल जाएगी। "
    "Supplier Name अपने आप प्रदर्शित होगा। "
    "Visitor Name फ़ील्ड में कार्यालय आने वाले व्यक्ति का नाम दर्ज करें। "
    "Designation फ़ील्ड में यह चुनें कि विज़िटर किससे मिलना चाहता है। "
    "उदाहरण के लिए MD Sir, GM Sir, Manager, Employee, या Others। "
    "विज़िटर का Mobile Number दर्ज करें। "
    "Number of Persons Visit में कुल विज़िटर्स की संख्या दर्ज करें। "
    "Visit Date चुनें। "
    "Visit Time चुनें, Morning या Afternoon। "
    "Comment Section में विज़िट का उद्देश्य लिखें। "
    "सभी विवरण भरने के बाद, Submit पर क्लिक करें। "
    "एक Success Alert दिखाई देगा। "
    "OK पर क्लिक करें। "
    "हमारी Management Team आपसे संपर्क करेगी। "
    "धन्यवाद। आपका दिन शुभ हो।.",
    "hi-IN-SwaraNeural"

    ),

    # "marathi.wav": (
    #     "नमस्कार. मी मराठी बोलतो. "
    #     "मराठी ही महाराष्ट्राची प्रमुख भाषा आहे. "
    #     "या भाषेला समृद्ध साहित्य आणि सांस्कृतिक परंपरा लाभली आहे. "
    #     "आजच्या आधुनिक तंत्रज्ञानाच्या युगात मराठी भाषेचा वापर मोठ्या प्रमाणावर होत आहे.",
    #     "kn-IN-SapnaNeural"
    # ),
    
    "english.wav": (
        " Welcome to SCM SILK Supplier Portal. "
        " This video explains how to book an appointment"
        ","
        " Open Google Chrome "
        ","
        " In the address bar, "
        " type www dot the SCM silk.com, "
        " press Enter, "
        " The Home Page will open, "
        " Click on Login Supplier Portal, "
        " Enter your User ID, "
        " and "
        " Password,"
        " then "
        " click Login, "
        " After, "
        " logging in,"
        " all options will appear on the left side "
        ","
        " Click on the Appointment option "
        ","
        " The Appointment Screen will open "
        ","
        " The Supplier Name will be auto-displayed "
        ","
        " In the Visitor Name field, "
        ","
        " enter the name of the person visiting the office  "
        ","
        " In the Designation field,"
        ","
        " select whom the visitor wants to meet  "
        ","
        " (MD Sir,"
        " GM Sir, "
        " Manager,"
        " Employee,"
        " or Others) "
        " Enter the Visitor Mobile Number, "
        " In Number of Persons Visit, "
        " enter the total number of visitors, "
        " Select the Visit Date, "
        " Select the Visit Time (AM or PM), "
        " In the Comment Section, "
        " enter the purpose of the visit, "
        " After filling in all details, "
        " click on Submit, "
        " A Success Alert will be displayed, "
        " Click OK, "
        " Our Management Team will contact you, "
        " Thank you. Have a good day!",
        "en-IN-NeerjaNeural"
    )
}

async def main():
    for filename, (text, voice) in voices.items():
        print(f"🔊 Generating {filename} ...")
        communicate = edge_tts.Communicate(text, voice)
        await communicate.save(filename)

    print("\n✅ All long-paragraph audio files generated successfully!")

asyncio.run(main())
