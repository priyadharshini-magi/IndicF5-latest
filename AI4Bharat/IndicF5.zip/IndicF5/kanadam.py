import asyncio
import edge_tts
import os

# Default voice controls
DEFAULT_RATE = "-5%"       # speed
DEFAULT_PITCH = "+3Hz"     # tone
DEFAULT_VOLUME = "+0%"

# Output folder name
OUTPUT_DIR = "kanadam_output"
OUTPUT_FILE = "scm2.wav"

# Ensure folder exists
os.makedirs(OUTPUT_DIR, exist_ok=True)

voices = {
    "kannada.wav": (
    "A V SEVEN S C M SILK ಪೂರೈಕೆದಾರ ಪೋರ್ಟಲ್‌ಗೆ ಸ್ವಾಗತ. "
    "ಈ ವಿಡಿಯೋದಲ್ಲಿ S C M SILK ಪೂರೈಕೆದಾರ ಪೋರ್ಟಲ್‌ನಲ್ಲಿ ಅಪಾಯಿಂಟ್‌ಮೆಂಟ್ ಅನ್ನು ಹೇಗೆ ಬುಕ್ ಮಾಡುವುದು ಎಂಬುದನ್ನು ಹಂತ ಹಂತವಾಗಿ ವಿವರಿಸಲಾಗುತ್ತದೆ. "
    "ಮೊದಲು Google Chrome ಅನ್ನು ತೆರೆಯಿರಿ. "
    "ಅಡ್ರೆಸ್ ಬಾರ್‌ನಲ್ಲಿ W W W . the s c m silk dot com ಅನ್ನು ಟೈಪ್ ಮಾಡಿ Enter ಒತ್ತಿರಿ. "
    "ಹೋಮ್ ಪೇಜ್ ತೆರೆಯುತ್ತದೆ. "
    "Login Supplier Portal  ಕ್ಲಿಕ್ ಮಾಡಿ. "
    "ನಿಮ್ಮ User name ಮತ್ತು Password ಅನ್ನು ನಮೂದಿಸಿ, ನಂತರ Login ಕ್ಲಿಕ್ ಮಾಡಿ. "
    "ಲಾಗಿನ್ ಆದ ನಂತರ, ಎಲ್ಲಾ ಆಯ್ಕೆಗಳು ಎಡಭಾಗದಲ್ಲಿ ಕಾಣಿಸುತ್ತವೆ. "
    "Appointment ಆಯ್ಕೆಯ  ಕ್ಲಿಕ್ ಮಾಡಿ. "
    "Appointment Screen ತೆರೆಯುತ್ತದೆ. "
    "Supplier Name ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಪ್ರದರ್ಶಿಸಲಾಗುತ್ತದೆ. "
    "Visitor Name ಫೀಲ್ಡ್‌ನಲ್ಲಿ ಕಚೇರಿಗೆ ಭೇಟಿ ನೀಡುವ ವ್ಯಕ್ತಿಯ ಹೆಸರನ್ನು ನಮೂದಿಸಿ. "
    "Designation ಫೀಲ್ಡ್‌ನಲ್ಲಿ ಭೇಟಿದಾರರು ಯಾರನ್ನು ಭೇಟಿಯಾಗಲು ಬಯಸುತ್ತಾರೆ ಎಂಬುದನ್ನು ಆಯ್ಕೆಮಾಡಿ. "
    "ಉದಾಹರಣೆಗೆ MD Sir, GM Sir, Manager, Employee ಅಥವಾ Others. "
    "ಭೇಟಿದಾರರ Mobile Number ಅನ್ನು ನಮೂದಿಸಿ. "
    "Number of Persons Visit ನಲ್ಲಿ ಒಟ್ಟು ಭೇಟಿದಾರರ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ. "
    "Visit Date ಅನ್ನು ಆಯ್ಕೆಮಾಡಿ. "
    "Visit Time ಅನ್ನು ಆಯ್ಕೆಮಾಡಿ, Morning ಅಥವಾ Afternoon. "
    "Comment Section ನಲ್ಲಿ ಭೇಟಿ."
    "ಎಲ್ಲಾ ವಿವರಗಳನ್ನು ತುಂಬಿದ ನಂತರ, Submit  ಕ್ಲಿಕ್ ಮಾಡಿ. "
    "ಒಂದು Success Alert ಪ್ರದರ್ಶಿಸಲಾಗುವುದು. "
    "OK ಕ್ಲಿಕ್ ಮಾಡಿ. "
    "ನಮ್ಮ Management Team ನಿಮ್ಮನ್ನು ಸಂಪರ್ಕಿಸುತ್ತಾರೆ. "
    "ಧನ್ಯವಾದಗಳು. ಉತ್ತಮ ದಿನವನ್ನು ಕಳೆಯಿರಿ.",
    "kn-IN-SapnaNeural",
    "+5%",
    "+3Hz"
    )
}
async def generate(filename, text, voice, rate, pitch):
    rate = rate or DEFAULT_RATE
    pitch = pitch or DEFAULT_PITCH
    output_path = os.path.join(OUTPUT_DIR, OUTPUT_FILE)

    print(f"🔊 Generating {output_path} | rate={rate}, pitch={pitch}")

    communicate = edge_tts.Communicate(
        text=text,
        voice=voice,
        rate=rate,
        pitch=pitch,
        volume=DEFAULT_VOLUME
    )

    await communicate.save(output_path)

async def main():
    await asyncio.gather(
        *[generate(filename, *data) for filename, data in voices.items()]
    )

    print("\n All audio files saved inside kanadam_output folder!")

#  THIS MUST BE AT FILE ROOT LEVEL
if __name__ == "__main__":
    asyncio.run(main())
