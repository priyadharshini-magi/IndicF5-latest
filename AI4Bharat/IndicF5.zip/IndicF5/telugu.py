import asyncio
import edge_tts
import os

# Default voice controls
DEFAULT_RATE = "-5%"       # speed
DEFAULT_PITCH = "+3Hz"     # tone
DEFAULT_VOLUME = "+0%"

# Output folder name
OUTPUT_DIR = "telugu_output"
OUTPUT_FILE = "scm2.wav"

# Ensure folder exists
os.makedirs(OUTPUT_DIR, exist_ok=True)

voices = {
    "telugu.wav": (
    "A V SEVEN S C M SILK సరఫరాదారు పోర్టల్‌కు స్వాగతం. "
    "ఈ వీడియోలో SCM SILK సరఫరాదారు పోర్టల్‌లో అపాయింట్‌మెంట్ ఎలా బుక్ చేయాలో స్టెప్ బై స్టెప్‌గా వివరించబడుతుంది. "
    "మొదట Google Chrome ఓపెన్ చేయండి. "
    "అడ్రస్ బార్‌లో www dot the scm silk dot com టైప్ చేసి Enter నొక్కండి. "
    "హోమ్ పేజ్ ఓపెన్ అవుతుంది. "
    "Login Supplier Portal పై క్లిక్ చేయండి. "
    "మీ User ID మరియు Password నమోదు చేసి, Login పై క్లిక్ చేయండి. "
    "లాగిన్ అయిన తర్వాత, అన్ని ఆప్షన్లు ఎడమ వైపు కనిపిస్తాయి. "
    "Appointment ఆప్షన్‌పై క్లిక్ చేయండి. "
    "Appointment Screen ఓపెన్ అవుతుంది. "
    "Supplier Name ఆటోమేటిక్‌గా చూపబడుతుంది. "
    "Visitor Name ఫీల్డ్‌లో కార్యాలయాన్ని సందర్శించే వ్యక్తి పేరు నమోదు చేయండి. "
    "Designation ఫీల్డ్‌లో సందర్శకుడు ఎవరిని కలవాలనుకుంటున్నారో ఎంపిక చేయండి. "
    "ఉదాహరణకు MD Sir, GM Sir, Manager, Employee, లేదా Others. "
    "సందర్శకుడి Mobile Number నమోదు చేయండి. "
    "Number of Persons Visit లో మొత్తం సందర్శకుల సంఖ్య నమోదు చేయండి. "
    "Visit Date ను ఎంపిక చేయండి. "
    "Visit Time ను ఎంపిక చేయండి, ఉదయం లేదా మధ్యాహ్నం. "
    "Comment Section లో సందర్శన ఉద్దేశాన్ని నమోదు చేయండి. "
    "అన్ని వివరాలు నమోదు చేసిన తర్వాత, Submit పై క్లిక్ చేయండి. "
    "ఒక Success Alert చూపబడుతుంది. "
    "OK పై క్లిక్ చేయండి. "
    "మా Management Team మీను సంప్రదిస్తుంది. "
    "ధన్యవాదాలు. మంచి రోజు గడపండి.",
    "te-IN-ShrutiNeural",
    "-10%",
    "+3Hz"
)

}

async def generate(filename, text, voice, rate, pitch):
    rate = rate or DEFAULT_RATE
    pitch = pitch or DEFAULT_PITCH
    output_path = os.path.join(OUTPUT_DIR, OUTPUT_FILE)

    print(f"🔊 Generating {output_path} | rate={rate}, pitch={pitch}")

    communicate = edge_tts.Communicate(
        text=text,
        voice=voice,
        rate=rate,
        pitch=pitch,
        volume=DEFAULT_VOLUME
    )

    await communicate.save(output_path)

async def main():
    await asyncio.gather(
        *[generate(filename, *data) for filename, data in voices.items()]
    )

    print("\n All audio files saved inside telugu_output folder!")

#  THIS MUST BE AT FILE ROOT LEVEL
if __name__ == "__main__":
    asyncio.run(main())