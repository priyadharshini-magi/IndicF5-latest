import asyncio
import edge_tts
import os

# Default voice controls
DEFAULT_RATE = "-5%"       # speed
DEFAULT_PITCH = "+3Hz"     # tone
DEFAULT_VOLUME = "+0%"

# Output folder name
OUTPUT_DIR = "malayalam_output"
OUTPUT_FILE = "scm2.wav"

# Ensure folder exists
os.makedirs(OUTPUT_DIR, exist_ok=True)
voices = {
    "malayalam.wav": (
    " A V SEVEN S C M SILK സപ്ലയർ പോർട്ടലിലേക്കു സ്വാഗതം. "
    "ഈ വീഡിയോയിൽ S C M SILK സപ്ലയർ പോർട്ടലിൽ അപോയിന്റ്മെന്റ് എങ്ങനെ ബുക്ക് ചെയ്യാമെന്ന് സ്റ്റെപ്പ് ബൈ സ്റ്റെപ്പായി വിശദീകരിക്കുന്നു. "
    "ആദ്യം Google Chrome തുറക്കുക. "
    "അഡ്രസ് ബാറിൽ www. the S C M silk dot com ടൈപ്പ് ചെയ്ത് Enter അമർത്തുക. "
    "ഹോം പേജ് തുറക്കും. "
    "Login Supplier Portal ക്ലിക്ക് ചെയ്യുക. "
    "നിങ്ങളുടെ User name and  Password നൽകുക, തുടർന്ന് Login ക്ലിക്ക് ചെയ്യുക. "
    "ലോഗിൻ ചെയ്ത ശേഷം, എല്ലാ ഓപ്ഷനുകളും ഇടത് വശത്ത് കാണാം. "
    "Appointment ഓപ്ഷനിൽ ക്ലിക്ക് ചെയ്യുക. "
    "Appointment Screen തുറക്കും. "
    "Supplier Name സ്വയമേവ പ്രദർശിപ്പിക്കും. "
    "Visitor Name ഫീൽഡിൽ ഓഫീസിൽ സന്ദർശിക്കുന്ന വ്യക്തിയുടെ പേര് നൽകുക. "
    "Designation ഫീൽഡിൽ സന്ദർശകൻ ആരെയാണു കാണാൻ ആഗ്രഹിക്കുന്നത് എന്ന് തിരഞ്ഞെടുക്കുക. "
    "ഉദാഹരണത്തിന് MD Sir, GM Sir, Manager, Employee, അല്ലെങ്കിൽ Others. "
    "സന്ദർശകന്റെ Mobile Number നൽകുക. "
    "Number of Persons Visit എന്നതിൽ മൊത്തം സന്ദർശകരുടെ എണ്ണം നൽകുക. "
    "Visit Date തിരഞ്ഞെടുക്കുക. "
    "Visit Time തിരഞ്ഞെടുക്കുക, Morning അല്ലെങ്കിൽ Afternoon. "
    "Comment Section ൽ സന്ദർശനത്തിന്റെ ഉദ്ദേശ്യം നൽകുക. "
    "എല്ലാ വിവരങ്ങളും നൽകിയ ശേഷം, Submit ക്ലിക്ക് ചെയ്യുക. "
    "ഒരു Success Alert പ്രദർശിപ്പിക്കും. "
    "OK ക്ലിക്ക് ചെയ്യുക. "
    "ഞങ്ങളുടെ Management Team നിങ്ങളെ ബന്ധപ്പെടും. "
    "നന്ദി. നല്ലൊരു ദിവസം ആശംസിക്കുന്നു.",
    "ml-IN-SobhanaNeural",
    "-10%",
    "+3Hz"
    )
}

async def generate(filename, text, voice, rate, pitch):
    rate = rate or DEFAULT_RATE
    pitch = pitch or DEFAULT_PITCH
    output_path = os.path.join(OUTPUT_DIR, OUTPUT_FILE)

    print(f"🔊 Generating {output_path} | rate={rate}, pitch={pitch}")

    communicate = edge_tts.Communicate(
        text=text,
        voice=voice,
        rate=rate,
        pitch=pitch,
        volume=DEFAULT_VOLUME
    )

    await communicate.save(output_path)

async def main():
    await asyncio.gather(
        *[generate(filename, *data) for filename, data in voices.items()]
    )

    print("\n All audio files saved inside malayalam_output folder!")

#  THIS MUST BE AT FILE ROOT LEVEL
if __name__ == "__main__":
    asyncio.run(main())
